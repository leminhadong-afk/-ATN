import React, { useEffect, useState } from "react";
import { Button, Typography, message, Space } from "antd";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Check, ShoppingBag, Home, FileText, Download } from "lucide-react";
import { OrderApi } from "../../../api/client/order/OrderApi";
import Header from "../HomePage/Header";
import Footer from "../HomePage/Footer";
import styles from "./CheckoutPage.module.css";

const { Title, Text } = Typography;

const PaymentSuccess = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [billId, setBillId] = useState(null);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    let id = searchParams.get("billId");
    if (!id) {
      const vnpOrderInfo = searchParams.get("vnp_OrderInfo");
      if (vnpOrderInfo) {
        const match = vnpOrderInfo.match(/- (.+)$/);
        if (match && match[1]) {
          id = match[1];
        }
      }
    }
    if (id) {
      setBillId(id);
    }
    window.scrollTo(0, 0);
  }, [searchParams]);

  const handleDownloadPDF = async () => {
    if (!billId) {
      message.error("Không tìm thấy thông tin đơn hàng");
      return;
    }

    setDownloading(true);
    try {
      const response = await OrderApi.downloadOrderPDF(billId);
      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `invoice_${billId}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      message.success("Tải hóa đơn thành công!");
    } catch (error) {
      console.error("Error downloading PDF:", error);
      message.error("Không thể tải hóa đơn. Vui lòng thử lại sau.");
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className={styles.layout}>
      <Header />
      <div className={styles.container}>
        <div className={styles.successContainer}>
          <div className={styles.successIcon}>
            <Check size={48} strokeWidth={3} />
          </div>
          
          <Title className={styles.successTitle}>Đặt hàng thành công!</Title>
          
          <div className={styles.successText}>
            Cảm ơn bạn đã tin tưởng và lựa chọn <span style={{ color: 'var(--primary-color)', fontWeight: 700 }}>ROYAL JEWELRY</span>.<br />
            Đơn hàng của bạn đang được xử lý và sẽ sớm được giao đến bạn.<br />
            Một email xác nhận đã được gửi đến địa chỉ của bạn.
          </div>

          {billId && (
            <div className={styles.orderNumber}>
              Mã đơn hàng: #{billId}
            </div>
          )}

          <div className={styles.actionButtons}>
            <Button 
              className={styles.btnPrimary} 
              type="primary" 
              icon={<Home size={18} />} 
              onClick={() => navigate("/")}
            >
              Về trang chủ
            </Button>
            
            <Button 
              className={styles.btnOutline} 
              icon={<ShoppingBag size={18} />} 
              onClick={() => navigate("/my-orders")}
            >
              Đơn hàng của tôi
            </Button>

            <Button 
              className={styles.btnOutline} 
              icon={<Download size={18} />} 
              onClick={handleDownloadPDF}
              loading={downloading}
              disabled={!billId}
            >
              Tải hóa đơn PDF
            </Button>
          </div>

          <div style={{ marginTop: 60, paddingTop: 40, borderTop: '1px solid #f0f0f0' }}>
            <Space size={40}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ color: 'var(--primary-color)', marginBottom: 8 }}><FileText size={24} /></div>
                <Text strong style={{ fontSize: 12 }}>Bảo hành trọn đời</Text>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ color: 'var(--primary-color)', marginBottom: 8 }}><ShoppingBag size={24} /></div>
                <Text strong style={{ fontSize: 12 }}>Đổi trả 30 ngày</Text>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ color: 'var(--primary-color)', marginBottom: 8 }}><Check size={24} /></div>
                <Text strong style={{ fontSize: 12 }}>Sản phẩm chính hãng</Text>
              </div>
            </Space>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default PaymentSuccess;

