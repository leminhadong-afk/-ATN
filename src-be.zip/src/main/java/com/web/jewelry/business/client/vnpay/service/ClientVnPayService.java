package com.web.jewelry.business.client.vnpay.service;

import com.web.jewelry.business.client.vnpay.request.ClientVnPayRequest;
import com.web.jewelry.business.client.vnpay.response.ClientVnPayResponse;

public interface ClientVnPayService {
	ClientVnPayResponse createVnPayPayment(ClientVnPayRequest request, String returnUrl, String notifyUrl);
	String handleVnPayCallback(java.util.Map<String, String> params);
}
